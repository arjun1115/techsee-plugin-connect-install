export default {
    SSO_APPLICATION: "tscc-sso-application-test-by-ajay",
    BUCKET: "tscc-web-app-bucket-test-by-ajay",
    WEB_APP: "tscc-web-app-test-by-ajay",
    CLOUDFRONT: "tscc-cf-distribution-test-by-ajay",
    SSO_LAMBDA: "tscc-sso-lambda-test-by-ajay",
    SSO_API: "tscc-sso-api-test-by-ajay",
    PROVISIONING_LAMBDA: "tscc-provisioing-lambda-test-by-ajay",
    PROVISIONING_API: "tscc-provisioing-api-test-by-ajay",
    ACTIVATION_LAMBDA: "tscc-activation-lambda-test-by-ajay",
    ACTIVATION_API: "tscc-activation-api-test-by-ajay",
    S3_PROVISIONING_POLICY: "tscc-s3-provisioning-policy-test-by-ajay",
    S3_ACTIVATION_POLICY:"tscc-s3-activation-policy-test-by-ajay",
    SSO_POLICY:"tscc-sso-policy-test-by-ajay",
    WEB_APP_STACK:"tscc-web-app-stack-test-by-ajay",
    CONFIG_STACK:"tscc-config-stack-test-by-ajay",
    SSO_STACK:"tscc-sso-stack-test-by-ajay"
};
