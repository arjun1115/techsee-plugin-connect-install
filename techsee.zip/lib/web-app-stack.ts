import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as apiGateway from "aws-cdk-lib/aws-apigateway";
import * as s3 from "aws-cdk-lib/aws-s3";
import * as s3Deployment from "aws-cdk-lib/aws-s3-deployment";
import * as cloudfront from "aws-cdk-lib/aws-cloudfront";
import * as sso from "aws-cdk-lib/aws-sso";
import * as iam from "aws-cdk-lib/aws-iam";
import ResourcesName from "./constants";
import * as fs from "fs";

interface WepAppStackProps extends cdk.StackProps {
    tscc_provisioning_api_url?: string;
    tscc_activation_api_url?: string;
}

export class WepAppStack extends cdk.Stack {
    distributionDomainName: string;
    constructor(scope: Construct, id: string, props?: WepAppStackProps) {
        super(scope, id, props);
        const s3PermissionsForLambda = new iam.PolicyStatement({
            actions: ["s3:ListAllMyBuckets", "s3:*Object"],
            resources: ["arn:aws:s3:::*"],
        });
        const connectPermissionsForLambda = new iam.PolicyStatement({
            actions: [
                "connect:Get*",
                "connect:Describe*",
                "connect:List*",
                "ds:DescribeDirectories",
            ],
            resources: ["*"],
        });

        const ssoPermissionsForLambda = new iam.PolicyStatement({
            actions: [
                "sso:ListAccountAssignments",
                "identitystore:ListGroupMemberships",
                "sso:ListPermissionSets",
                "sso:ListAccountsForProvisionedPermissionSet",
                "sso:ListInstances",
                "sso:DescribePermissionSet",
            ],
            resources: ["*"],
        });

        ///////////////////////////////////////////////////////////////////////////////
        /**
         *s3 bucket for static react app
         */
        const tscc_web_app_bucket = new s3.Bucket(this, ResourcesName.BUCKET, {
            publicReadAccess: true,
            bucketName: ResourcesName.BUCKET,
            removalPolicy: cdk.RemovalPolicy.DESTROY,
            autoDeleteObjects: true,
        });

        // web app deployment
        new s3Deployment.BucketDeployment(this, ResourcesName.WEB_APP, {
            sources: [s3Deployment.Source.asset("./resources/build")],
            destinationBucket: tscc_web_app_bucket,
        });

        // Cloudfront
        const cf = new cloudfront.CloudFrontWebDistribution(
            this,
            ResourcesName.CLOUDFRONT,
            {
                originConfigs: [
                    {
                        s3OriginSource: {
                            s3BucketSource: tscc_web_app_bucket,
                        },
                        behaviors: [{ isDefaultBehavior: true }],
                    },
                ],
                defaultRootObject: "index.html",
            }
        );
        this.distributionDomainName = cf.distributionDomainName;
    }
}
